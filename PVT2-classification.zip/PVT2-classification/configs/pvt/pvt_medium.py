cfg = dict(
    model='pvt_medium',
    drop_path=0.3,
    clip_grad=1.0,
    output_dir='checkpoints/pvt_medium',
)